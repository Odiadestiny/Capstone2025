package cookiegram.ca.application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CookieGramAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
